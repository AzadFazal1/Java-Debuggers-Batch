package com.BinaryLogic;

import org.springframework.stereotype.Controller;

@Controller
public class HomeController {
	
	@RequestMapping("/mainmenu")
	public String showPage() {
		return "main-menu";
	}

}
